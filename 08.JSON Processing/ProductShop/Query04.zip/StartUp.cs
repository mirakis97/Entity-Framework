﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new ProductShopContext();
            //db.Database.EnsureDeleted();
            //db.Database.EnsureCreated();
            //Problem01
            //string jsonString = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\ProductShop\Datasets\users.json");
            //Console.WriteLine(ImportUsers(db,jsonString));
            //Problem02
            //string jsonString = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\ProductShop\Datasets\products.json");
            //Console.WriteLine(ImportUsers(db, jsonString));
            //Problem03
            string jsonString = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\ProductShop\Datasets\categories.json");
            Console.WriteLine(ImportUsers(db, jsonString));

        }
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            List<User> users = JsonConvert.DeserializeObject<List<User>>(inputJson);
            context.Users.AddRange(users);
            int count = users.Count();
            context.SaveChanges();
            return $"Successfully imported {count}";
        }

        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            List<Product> products = JsonConvert.DeserializeObject<List<Product>>(inputJson);
            context.Products.AddRange(products);
            int count = products.Count();
            context.SaveChanges();
            return $"Successfully imported {count}";
        }
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            List<Category> categories = JsonConvert.DeserializeObject<List<Category>>(inputJson).Where(x => x.Name != null).ToList();
            context.Categories.AddRange(categories);
            int count = categories.Count();
            context.SaveChanges();
            return $"Successfully imported {count}";
        }
    }
}