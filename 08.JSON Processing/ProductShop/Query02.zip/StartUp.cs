﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new ProductShopContext();
            //db.Database.EnsureDeleted();
            //db.Database.EnsureCreated();
            string jsonString = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\ProductShop\Datasets\users.json");
            Console.WriteLine(ImportUsers(db,jsonString));

        }
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            List<User> users = JsonConvert.DeserializeObject<List<User>>(inputJson);
            context.Users.AddRange(users);
            int count = users.Count();
            context.SaveChanges();
            return $"Successfully imported {count}";
        }
    }
}