﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        private static string RESULT_DIRECTORY_PATH = @"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\CarDealer\Datasets\Results";

        public static void Main(string[] args)
        {
            var db = new CarDealerContext();
            //db.Database.EnsureDeleted();
            //db.Database.EnsureCreated();
            //Problem01
            //string jsonString1 = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\CarDealer\Datasets\suppliers.json");
            //Console.WriteLine(ImportSuppliers(db, jsonString1));
            //Problem02
            //string jsonString2 = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\CarDealer\Datasets\parts.json");
            //Console.WriteLine(ImportParts(db, jsonString2));
            //Problem03
            //string jsonString3 = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\CarDealer\Datasets\cars.json");
            //Console.WriteLine(ImportCars(db, jsonString3));
            //Problem03
            //string jsonString4 = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\CarDealer\Datasets\customers.json");
            //Console.WriteLine(ImportCustomers(db, jsonString4));
            //Problem04
            //string jsonString5 = File.ReadAllText(@"C:\Miroslav Apps\Programing\SoftUni\C# Web Developer\DB\Entity Framework\JSON Processing\CarDealer\Datasets\sales.json");
            //Console.WriteLine(ImportSales(db, jsonString5));

            string result = GetOrderedCustomers(db);
            if (!Directory.Exists(RESULT_DIRECTORY_PATH))
            {
                Directory.CreateDirectory(RESULT_DIRECTORY_PATH);
            }
            File.WriteAllText($"{RESULT_DIRECTORY_PATH}/GetOrderedCustomers.json", result);

        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            List<Supplier> suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);
            context.Suppliers.AddRange(suppliers);
            int count = suppliers.Count();
            context.SaveChanges();
            return $"Successfully imported {count}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            List<Part> parts = JsonConvert.DeserializeObject<List<Part>>(inputJson);
            var suppliers = context.Suppliers.Select(s => s.Id);
            parts = parts.Where(p => suppliers.Any(s => s == p.SupplierId)).ToList();
            context.Parts.AddRange(parts);
            int count = parts.Count();
            context.SaveChanges();
            return $"Successfully imported {count}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var cars = JsonConvert.DeserializeObject<List<ImportCarDto>>(inputJson);
            List<Car> listOfcars = new List<Car>();
            foreach (var carJson in cars)
            {
                Car car = new Car()
                {
                    Make = carJson.Make,
                    Model = carJson.Model,
                    TravelledDistance = carJson.TravelledDistance
                };
                foreach (var partId in carJson.PartsId.Distinct())
                {
                    car.PartCars.Add(new PartCar()
                    {
                        Car = car,
                        PartId = partId
                    });
                }
                listOfcars.Add(car);
            }
            context.Cars.AddRange(listOfcars);
            int count = listOfcars.Count();
            context.SaveChanges();
            return $"Successfully imported {count}.";
        }
        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            List<Customer> customers = JsonConvert.DeserializeObject<List<Customer>>(inputJson);
            context.Customers.AddRange(customers);
            int count = customers.Count();
            context.SaveChanges();
            return $"Successfully imported {count}.";
        }
        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            List<Sale> sales = JsonConvert.DeserializeObject<List<Sale>>(inputJson);
            context.Sales.AddRange(sales);
            int count = sales.Count();
            context.SaveChanges();
            return $"Successfully imported {count}.";
        }

        public static string GetOrderedCustomers(CarDealerContext context)
        {
            var customures = context.Customers
                .Select(x => new
                {
                    Name = x.Name,
                    BirthDate = x.BirthDate,
                    IsYoungDriver = x.IsYoungDriver
                }).OrderBy(x => x.BirthDate).ThenBy(x => x.IsYoungDriver).ToList();

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.DateFormatString = "dd/MM/yyyy";
            jsonSettings.Formatting = Formatting.Indented;
            string customersJson = JsonConvert.SerializeObject(customures, jsonSettings);

            return customersJson;
        }
    }
}