﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            //01.
            //string problem1 = Console.ReadLine();
            //Console.WriteLine(GetBooksByAgeRestriction(db,problem1));
            //02.
            // Console.WriteLine(GetGoldenBooks(db));
            //03.
            //Console.WriteLine(GetBooksByPrice(db));
            //04.
            int year = int.Parse(Console.ReadLine());
            Console.WriteLine(GetBooksNotReleasedIn(db, year));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var books = context.Books
                .AsEnumerable()
                .Where(x => x.AgeRestriction.ToString().ToLower() == command.ToLower())
                .Select(x => new { x.Title }).OrderBy(x => x.Title);

            StringBuilder sb = new StringBuilder();

            foreach (var book in books)
            {
                sb.AppendLine($"{book.Title}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            var books = context.Books
                .AsEnumerable()
                .Where(x => x.EditionType.ToString() == "Gold" && x.Copies < 5000)
                .Select(x => new
                {
                    x.BookId,
                    x.Title
                }).OrderBy(x => x.BookId);
            StringBuilder sb = new StringBuilder();

            foreach (var book in books)
            {
                sb.AppendLine($"{book.Title}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            var books = context.Books
             .Where(x => x.Price > 40)
             .Select(x => new
             {
                 x.BookId,
                 x.Title,
                 x.Price
             }).OrderByDescending(x => x.Price);
            StringBuilder sb = new StringBuilder();

            foreach (var book in books)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var books = context.Books
            .Where(x => x.ReleaseDate.Value.Year != year)
            .Select(x => new
            {
                x.BookId,
                x.Title,
                x.Price
            }).OrderBy(x => x.BookId);
            StringBuilder sb = new StringBuilder();

            foreach (var book in books)
            {
                sb.AppendLine($"{book.Title}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
